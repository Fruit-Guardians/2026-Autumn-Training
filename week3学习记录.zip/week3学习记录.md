# week3学习记录

# 预备知识

## 第一节 基本工具的安装与使用

### 作业Writeup

#### **\[SWPUCTF 2021 新生赛\]gift\_F12**

题型：源码泄露

考点：F12查看网页源码

1. 开启靶场环境，访问题目页面

![image\.png](图片和附件/image%205.png)

2. 按下F12打开开发者工具，Ctrl \+ U查看网页源代码

![image\.png](图片和附件/image%2014.png)

3. Ctrl \+ F在源码中直接找到flag

![image\.png](图片和附件/image%206.png)

4. 修改成NSSCTF\{\}形式，拿到flag

![d18eb4eb70955f068dbc67ecf6e4db8e\.png](图片和附件/d18eb4eb70955f068dbc67ecf6e4db8e.png)

#### robots\.txt

题型：robots\.txt 信息泄露

考点：认识robots协议、网站根目录文件访问

1. 下发赛题，打开靶场网页

![image\.png](图片和附件/image%207.png)

2. 在网址后面加上 `/robots.txt` ，访问这个文件

![image\.png](图片和附件/image%2013.png)

3. 复制第三个secret\.php,拼到网址上访问拿到账号密码

![image\.png](图片和附件/image%201.png)

4. 复制第二个路径，拼到网址上直接访问，登录页面拿到flag

![image\.png](图片和附件/image%2016.png)

#### Robots\.txt

题型：robots\.txt 信息泄露

考点：robots协议，网站敏感路径泄露

1. 点击【下发赛题】，打开靶场链接

![image\.png](图片和附件/image%2019.png)

2. 在靶场网址后面拼接 `/robots.txt` 进行访问

![image\.png](图片和附件/image%2015.png)

3. 查看robots\.txt中的Disallow行，访问这个隐藏地址，页面中得到flag

![image\.png](图片和附件/image.png)

#### \[\[MoeCTF 2021\]Web安全入门指北—GET

题型：GET传参

考点：HTTP GET请求、URL参数传递

1. 开启靶场，拿到靶场基础网址

![image\.png](图片和附件/image%203.png)

2. GET参数写在URL问号后面，构造参数 `?moe=flag`，进行访问

![image\.png](图片和附件/image%2011.png)

3. 拿到flag

![image\.png](图片和附件/image%2010.png)

### 学习总结

##### F12

- flag 外层标识要改成 NSSCTF，不能直接复制源码里的 WLLMCTF

- 遇到简单 Web 题优先检查：F12、Ctrl\+U 源码

##### robot

###### robots\.txt 是什么

- robots\.txt 放在网站根目录，是给爬虫（搜索引擎机器人）看的协议文件：

- User\-agent: \*：对所有爬虫生效

- Disallow: /xxx：禁止爬虫访问这个路径

👉 CTF 套路：Disallow 后面写的就是藏 flag 的地址，是提示线索。

###### Robots\.txt的r进行URL编码

- 直接访问 /robots\.txt，会自动把小写 r 转成大写 R → 跳转到介绍页面

- 小写字母 r 的 URL 编码：%72

- 访问 /%72obots\.txt 等价于 /robots\.txt

- 服务器不会对编码 %72 自动转大写，成功读到原始 robots\.txt

##### HTTP GET请求

- GET 参数固定语法：目标url?参数名=参数值，多参数使用\&连接：url?a=1\&b=2

- 检测 GET 参数moe，当它的值严格等于flag时，输出 flag；缺少该参数、参数名写错、参数值不对，都不会返回 flag

#### 笔记记录上传

![b59a68b38ed32cd3a06c2b4a421adad4\_720\.png](图片和附件/b59a68b38ed32cd3a06c2b4a421adad4_720.png)

## 第二节 Linux 操作系统

### 搭建一个linux环境（wsl2）

![image\.png](图片和附件/image%204.png)

### 学习记录

#### Linux 系统内核与 Linux 发行套件的区别

- Linux系统内核指的是由Linus Torvalds负责维护，提供硬件抽象层、硬盘及文件系统控制及多任务功能的系统核心程序。

- Linux发行套件系统是我们常说的 Linux操作系统，也即是由 Linux内核与各种常用软件的集合产品。

#### Linux 文件基本属性

在 Linux 中我们通常使用以下两个命令来修改文件或目录的所属用户与权限：

chown \(change owner\) ： 修改所属用户与组。

chmod \(change mode\) ： 修改用户的权限。

#### Linux 文件与目录管理

- ls（英文全拼：list files）: 列出目录及文件名

- cd（英文全拼：change directory）：切换目录

- pwd（英文全拼：print work directory）：显示目前的目录

- mkdir（英文全拼：make directory）：创建一个新的目录

- rmdir（英文全拼：remove directory）：删除一个空的目录

- cp（英文全拼：copy file）: 复制文件或目录

- rm（英文全拼：remove）: 删除文件或目录

- mv（英文全拼：move file）: 移动文件与目录，或修改文件与目录的名称

![image\.png](图片和附件/image%208.png)

#### Linux 文件内容查看

- cat  由第一行开始显示文件内容

- tac  从最后一行开始显示，可以看出 tac 是 cat 的倒着写！

- nl   显示的时候，顺道输出行号！

- more 一页一页的显示文件内容

- less 与 more 类似，但是比 more 更好的是，他可以往前翻页！

- head 只看头几行

- tail 只看尾巴几行

![image\.png](图片和附件/image%2018.png)

#### Linux 用户和用户组管理

##### 一，Linux系统用户账号的管理

###### 1、添加新的用户账号使用useradd命令，其语法如下

*** useradd 选项 用户名***

选项:\-c comment 指定一段注释性描述。

\-d 目录 指定用户主目录，如果此目录不存在，则同时使用\-m选项，可以创建主目录。

\-g 用户组 指定用户所属的用户组。

\-G 用户组，用户组 指定用户所属的附加组。

\-s Shell文件 指定用户的登录Shell。 

\-u 用户号 指定用户的用户号，如果同时有\-o选项，则可以重复使用其他用户的标识号。

用户名:指定新账号的登录名。

###### 2、删除帐号

删除一个已有的用户账号使用userdel命令，其格式如下

***userdel 选项 用户名***

常用的选项是 \-r，它的作用是把用户的主目录一起删除

###### 3、修改帐号

修改已有用户的信息使用usermod命令，其格式如下：

***usermod 选项 用户名***

- 常用的选项包括\-c, \-d, \-m, \-g, \-G, \-s, \-u以及\-o等，这些选项的意义与useradd命令中的选项一样，可以为用户指定新的资源值。

- 有些系统可以使用选项：\-l 新用户名

- 这个选项指定一个新的账号，即将原来的用户名改为新的用户名。  

###### 4、用户口令的管理

指定和修改用户口令的Shell命令是passwd。超级用户可以为自己和其他用户指定口令，普通用户只能用它修改自己的口令。命令的格式为：

***passwd 选项 用户名***

可使用的选项：

\-l 锁定口令，即禁用账号。

\-u 口令解锁。

\-d 使账号无口令。

\-f 强迫用户下次登录时修改口令。

如果默认用户名，则修改当前用户的口令。

- 如果是超级用户，可以用下列形式指定任何用户的口令：

passwd sam

New password:\*\*\*\*\*\*\* 

Re\-enter new password:**\*\*\*** 

- 普通用户修改自己的口令时，passwd命令会先询问原口令，验证后再要求用户输入两遍新口令，如果两次输入的口令一致，则将这个口令指定给用户；而超级用户为用户指定口令时，就不需要知道原口令。

- 为了系统安全起见，用户应该选择比较复杂的口令，例如最好使用8位长的口令，口令中包含有大写、小写字   母和数字，并且应该与姓名、生日等不相同。

- 为用户指定空口令时，执行下列形式的命令：

***passwd \-d sam***

##### 二、Linux系统用户组的管理

###### 1、增加一个新的用户组使用groupadd命令。其格式如下：

*** groupadd 选项 用户组***

可以使用的选项有：



\-g GID 指定新用户组的组标识号（GID）。

\-o 一般与\-g选项同时使用，表示新用户组的GID可以与系统已有用户组的GID相同。

###### 2\.如果要删除一个已有的用户组，使用groupdel命令，其格式如下：

***  groupdel 用户组***

###### 3、修改用户组的属性使用groupmod命令。其语法如下：

***groupmod 选项 用户组***

常用的选项有：

\-g GID 为用户组指定新的组标识号。

\-o 与\-g选项同时使用，用户组的新GID可以与系统已有用户组的GID相同。

\-n新用户组 将用户组的名字改为新名字

###### 4、如果一个用户同时属于多个用户组，那么用户可以在用户组之间切换，以便具有其他用户组的权限。

用户可以在登录后，使用命令newgrp切换到其他用户组，这个命令的参数就是目的用户组。

##### 三、与用户账号有关的系统文件

/etc/passwd文件是用户管理工作涉及的最重要的一个文件。

Linux系统中的每个用户都在/etc/passwd文件中有一个对应的记录行，它记录了这个用户的一些基本属性。

##### 四、添加批量用户

###### （1）先编辑一个文本用户文件。

每一列按照/etc/passwd密码文件的格式书写，要注意每个用户的用户名、UID、宿主目录都不可以相同，其中密码栏可以留做空白或输入x号。

###### （2）以root身份执行命令 /usr/sbin/newusers，从刚创建的用户文件user\.txt中导入数据，创建用户： newusers \< user\.txt

然后可以执行命令 vipw 或 vi /etc/passwd 检查 /etc/passwd 文件是否已经出现这些用户的数据，并且用户的宿主目录是否已经创建。

###### （3）执行命令/usr/sbin/pwunconv。

将 /etc/shadow 产生的 shadow 密码解码，然后回写到 /etc/passwd 中，并将/etc/shadow的shadow密码栏删掉。这是为了方便下一步的密码转换工作，即先取消 shadow password 功能。

###### （4）编辑每个用户的密码对照文件。

格式为：用户名:密码

###### （5）以 root 身份执行命令 /usr/sbin/chpasswd。

创建用户密码，chpasswd 会将经过 /usr/bin/passwd 命令编码过的密码写入 /etc/passwd 的密码栏。

\#chpasswd \< passwd\.txt

###### （6）确定密码经编码写入/etc/passwd的密码栏后。

执行命令 /usr/sbin/pwconv 将密码编码为 shadow password，并将结果写入 /etc/shadow。

\#pwconv

### 作业Writeup

#### Linux之旅

题型：Web 命令注入

考点：bash特殊语法、命令注入绕过黑名单

- 第一步：打开靶场链接

![image\.png](图片和附件/image%2017.png)

- 第二步：观察页面输入点，按q进入linux安装系统，登录进入系统

- 第三步：完成新手任务

![image\.png](图片和附件/image%209.png)



![image\.png](图片和附件/image%202.png)

- 第四步：拿到flag提交

![image\.png](图片和附件/image%2012.png)

（我那拿不到flag呀，我输入了好多次都找不到/\(ㄒoㄒ\)/\~\~）

#### 笔记记录上传

![ead4ec6ef0e374b2417a8cddd2aee6fe\_720\.png](图片和附件/ead4ec6ef0e374b2417a8cddd2aee6fe_720.png)

![a8dcbbbac5ab0f0199a372f5290b1e48\_720\.png](图片和附件/a8dcbbbac5ab0f0199a372f5290b1e48_720.png)



